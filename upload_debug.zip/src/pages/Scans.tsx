import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { useAuth } from '../hooks/useAuth'
import { CloudArrowUpIcon, DocumentIcon } from '@heroicons/react/24/outline'

const MAX_FILE_SIZE = 10 * 1024 * 1024 // 10MB

export default function Scans() {
  const { token } = useAuth()
  const queryClient = useQueryClient()
  const [selectedFile, setSelectedFile] = useState<File | null>(null)
  const [scanName, setScanName] = useState('')
  const [uploadResult, setUploadResult] = useState<any>(null)
  const [uploadProgress, setUploadProgress] = useState(0)
  const [error, setError] = useState('')

  // Query to list scans
  const { data: scans, isLoading: isLoadingScans } = useQuery({
    queryKey: ['scans'],
    queryFn: async () => {
      const res = await fetch('/api/scans/list', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })
      if (!res.ok) {
        throw new Error('Failed to fetch scans')
      }
      return res.json()
    },
    enabled: !!token
  })

  // Upload mutation
  const uploadMutation = useMutation({
    mutationFn: async ({ file, name }: { file: File, name: string }) => {
      const formData = new FormData()
      formData.append('file', file)
      if (name) {
        formData.append('name', name)
      }

      setUploadProgress(0)
      setError('')
      setUploadResult(null)

      const res = await fetch('/api/scans/upload', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`
        },
        body: formData
      })

      if (!res.ok) {
        let errorMessage = 'Upload failed'
        try {
          const errorData = await res.json()
          errorMessage = errorData.message || errorData.error || 'Upload failed'
        } catch (parseError) {
          // If response isn't JSON, try to get text
          try {
            const errorText = await res.text()
            errorMessage = errorText || `HTTP ${res.status}: ${res.statusText}`
          } catch (textError) {
            errorMessage = `HTTP ${res.status}: ${res.statusText}`
          }
        }
        throw new Error(errorMessage)
      }

      setUploadProgress(100)
      return res.json()
    },
    onSuccess: (data) => {
      setUploadResult(data)
      queryClient.invalidateQueries({ queryKey: ['scans'] })
      setSelectedFile(null)
      setScanName('')
    },
    onError: (error) => {
      setError(error instanceof Error ? error.message : 'Upload failed')
      setUploadProgress(0)
    }
  })

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return

    if (file.size > MAX_FILE_SIZE) {
      setError(`File too large. Maximum size is ${Math.round(MAX_FILE_SIZE / (1024 * 1024))}MB`)
      return
    }

    setError('')
    setSelectedFile(file)
    
    // Auto-generate scan name if not provided
    if (!scanName) {
      const today = new Date().toISOString().split('T')[0]
      const baseName = file.name.split('.')[0]
      setScanName(`${baseName}-${today}`)
    }
  }

  const handleUpload = () => {
    if (!selectedFile) return

    uploadMutation.mutate({
      file: selectedFile,
      name: scanName || selectedFile.name
    })
  }

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes'
    const k = 1024
    const sizes = ['Bytes', 'KB', 'MB', 'GB']
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i]
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString()
  }

  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900">Scan Upload</h1>
        <p className="mt-2 text-sm text-gray-600">
          Upload security scan files for processing. Files are stored per-tenant and isolated server-side.
        </p>
      </div>

      {/* Upload Card */}
      <div className="bg-white shadow sm:rounded-lg mb-8">
        <div className="px-4 py-5 sm:p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Upload Scan File</h3>
          
          {/* Scan Name Input */}
          <div className="mb-4">
            <label htmlFor="scan-name" className="block text-sm font-medium text-gray-700">
              Name
            </label>
            <input
              type="text"
              id="scan-name"
              value={scanName}
              onChange={(e) => setScanName(e.target.value)}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
              placeholder="nuclei-2024-09-05.jsonl"
            />
          </div>

          {/* File Input */}
          <div className="mb-4">
            <label htmlFor="file-upload" className="block text-sm font-medium text-gray-700">
              File
            </label>
            <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-md">
              <div className="space-y-1 text-center">
                <CloudArrowUpIcon className="mx-auto h-12 w-12 text-gray-400" />
                <div className="flex text-sm text-gray-600">
                  <label
                    htmlFor="file-upload"
                    className="relative cursor-pointer bg-white rounded-md font-medium text-indigo-600 hover:text-indigo-500 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-indigo-500"
                  >
                    <span>Upload a file</span>
                    <input
                      id="file-upload"
                      name="file-upload"
                      type="file"
                      className="sr-only"
                      accept=".json,.jsonl,.xml,.txt"
                      onChange={handleFileSelect}
                    />
                  </label>
                  <p className="pl-1">or drag and drop</p>
                </div>
                <p className="text-xs text-gray-500">
                  JSON, JSONL, XML, TXT up to 10MB
                </p>
              </div>
            </div>
          </div>

          {/* Selected File Info */}
          {selectedFile && (
            <div className="mb-4 p-3 bg-gray-50 rounded-md">
              <p className="text-sm text-gray-900">
                <strong>Selected:</strong> {selectedFile.name} ({formatFileSize(selectedFile.size)})
              </p>
            </div>
          )}

          {/* Error Display */}
          {error && (
            <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-md">
              <p className="text-sm text-red-800">{error}</p>
            </div>
          )}

          {/* Upload Progress */}
          {uploadMutation.isPending && (
            <div className="mb-4">
              <div className="bg-gray-200 rounded-full h-2">
                <div 
                  className="bg-indigo-600 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${uploadProgress}%` }}
                ></div>
              </div>
              <p className="text-sm text-gray-600 mt-1">Uploading... {uploadProgress}%</p>
            </div>
          )}

          {/* Upload Button */}
          <button
            onClick={handleUpload}
            disabled={!selectedFile || uploadMutation.isPending}
            className="w-full inline-flex justify-center items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <CloudArrowUpIcon className="-ml-1 mr-2 h-5 w-5" aria-hidden="true" />
            {uploadMutation.isPending ? 'Uploading...' : 'Upload'}
          </button>

          {/* Upload Result */}
          {uploadResult && (
            <div className="mt-4 p-3 bg-green-50 border border-green-200 rounded-md">
              <h4 className="text-sm font-medium text-green-800 mb-2">Upload Successful</h4>
              <pre className="text-xs text-green-700 bg-green-100 p-2 rounded overflow-x-auto">
                {JSON.stringify(uploadResult, null, 2)}
              </pre>
            </div>
          )}
        </div>
      </div>

      {/* Scans List */}
      <div className="bg-white shadow sm:rounded-lg">
        <div className="px-4 py-5 sm:p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Uploaded Scans</h3>
          
          {isLoadingScans ? (
            <div className="text-center py-4">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600 mx-auto"></div>
              <p className="mt-2 text-sm text-gray-500">Loading scans...</p>
            </div>
          ) : scans?.length > 0 ? (
            <div className="overflow-hidden">
              <ul className="divide-y divide-gray-200">
                {scans.map((scan: any, index: number) => (
                  <li key={scan.key || index} className="py-3">
                    <div className="flex items-center space-x-3">
                      <DocumentIcon className="h-6 w-6 text-gray-400" />
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-gray-900 truncate">
                          {scan.key.split('/').pop()}
                        </p>
                        <p className="text-sm text-gray-500">
                          {formatFileSize(scan.size)} • {formatDate(scan.uploadedAt)}
                        </p>
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          ) : (
            <div className="text-center py-8">
              <DocumentIcon className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-sm text-gray-500">No scans uploaded yet</p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}